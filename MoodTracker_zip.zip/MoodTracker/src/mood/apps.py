from django.apps import AppConfig


class MoodConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mood'
