from django.shortcuts import render, redirect
from account.models import Account
from personal.models import DiaryEntry

# Create your views here.
def home_screen_view(request):

#    context = {
#       'some_string': "this is some string that I'm passing to the view",
#    }

    context = {}

    accounts = Account.objects.all()
    context['accounts'] = accounts

    return render (request, "personal/home.html", context)



# Create your views here.
def diary_dashboard(request):
    context = {}
    entries = DiaryEntry.objects.all()
    context['entries'] = entries

    return  render(request, 'personal/user_dashboard.html', context)
# View to render the form

