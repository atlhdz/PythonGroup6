from django.contrib import admin
from personal.models import DiaryEntry

admin.site.register(DiaryEntry)
