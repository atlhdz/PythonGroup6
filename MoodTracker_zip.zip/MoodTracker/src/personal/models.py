from django.db import models
from django.contrib.auth.models import User

MOOD_CHOICES = [
    ("01", "Very Unhappy"),
    ("02", "Unhappy"),
    ("03", "Somewhat Unhappy"),
    ("04", "Fine"),
    ("05", "Neutral"),
    ("06", "Good"),
    ("07", "Somewhat Happy"),
    ("08", "Happy"),
    ("09", "Very Happy"),
    ("10", "Excellent"),
]

class DiaryEntry(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField(max_length=1000)
    mood = models.CharField(max_length=2, choices=MOOD_CHOICES, default="05")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    def __str__(self):
        return self.title
    class Meta:
        verbose_name = "A Diary Entry"
        verbose_name_plural = "Diary Entries"



